/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package real_tubes;

/**
 *
 * @author Lenovo
 */
public class User_session {
    private static User_session instance;
    private String username;

    private User_session() {}

    public static User_session getInstance() {
        if (instance == null) {
            instance = new User_session();
        }
        return instance;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}

